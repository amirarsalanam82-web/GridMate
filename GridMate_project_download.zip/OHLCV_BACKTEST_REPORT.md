# GridMate v0.3.7 — OHLCV backtest stage

The backtest engine now accepts OHLCV bars in addition to the legacy close-only format.

## Changes
- Added `OHLCBar` and `load_ohlcv_csv()`.
- Grid levels can be touched by intrabar high/low, not only the closing price.
- Stop-loss checks the bar low, reducing the chance of missing an intrabar stop.
- Kept the existing conservative execution model: fees, slippage, minimum notional, and order cap.
- Added `touched_levels` metric.
- Existing close-only API remains compatible.

## Important limitation
OHLC candles do not reveal the exact order in which high and low occurred inside a candle. GridMate therefore uses a deterministic conservative path so results remain reproducible. This is still not an exchange-grade matching engine.

## Real-data status
The project now has a clean OHLCV importer ready for real historical data. External market-data retrieval was not embedded into this release, so no synthetic result is presented as evidence of profitability.
