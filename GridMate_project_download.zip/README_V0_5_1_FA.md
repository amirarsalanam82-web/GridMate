# GridMate v0.5.1

این نسخه یک قدم به APK واقعی نزدیک‌تر است: پروژه Android اکنون Activity واقعی، کنترل Health/Status/Start/Stop و Kill Switch دارد و به build ابری متصل است.

هنوز اتصال Live به حساب و کلید API داخل اپ فعال نشده است.
