# Android UI Report — v0.4.7

- Android application module added.
- Basic Grid configuration screen added.
- Start / Stop / Kill Switch controls added.
- Paper/Dry-Run is explicitly the default.
- No real exchange credentials are stored in the app.
- No withdrawal capability exists.
- APK was NOT built in this environment because Android SDK/Gradle tooling is unavailable; do not treat this as an installable APK yet.
