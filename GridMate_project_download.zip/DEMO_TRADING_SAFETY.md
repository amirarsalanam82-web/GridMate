# Demo Trading Safety Gate

GridMate now contains a small Binance Spot Demo Mode adapter.

- It targets `https://demo-api.binance.com/api` only.
- Credentials are read from environment variables.
- No withdrawal/transfer endpoint is implemented.
- The first order adapter exposes LIMIT orders only.
- Live production endpoints are not used by this adapter.
- Real-money mode remains disabled until a separate explicit safety gate is built and tested.

Binance's current documentation says Demo Mode uses the demo REST endpoint and that its prices/order books are similar to live market data, while also warning that Demo Mode results should not be assumed to work in live trading.
