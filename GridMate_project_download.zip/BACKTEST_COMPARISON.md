# Benchmarking policy

GridMate should be compared against Buy & Hold on the **same exact bars, starting capital, and evaluation period**.

The benchmark is descriptive, not predictive. A grid result that beats Buy & Hold in one sample does not establish future profitability.

## Required reporting
- period and candle interval
- starting capital
- GridMate ending equity / return
- Buy & Hold ending equity / return
- max drawdown for both
- fees, slippage and rejected orders for GridMate
- stop-loss status

Do not cherry-pick periods. Prefer multiple contiguous periods and out-of-sample validation before any demo trading.
