# Grid Runner v0.4.4

- Added conservative `GridRunner` with explicit Dry-Run default.
- Grid triggers only on observed price crossings.
- Live mode requires an explicit submit callback; there is no implicit live trading.
- Kill switch prevents starting the runner.
- Dry-run events do not create exchange orders.
- Reuses OrderManager safety limits and idempotency.
- No withdrawal capability.

Validation: 13 targeted tests passed (runner + order manager + reconciliation + Wallex adapter).

Next: persistent runner state, reconnect/reconciliation loop, and Android status controls before any live order path.
