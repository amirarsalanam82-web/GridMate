import unittest
from unittest.mock import Mock
from .wallex import WallexClient, WallexConfig, WallexAPIError

class FakeResponse:
    def __init__(self, status, payload): self.status_code=status; self.payload=payload
    def json(self): return self.payload

class FakeSession:
    def __init__(self, response): self.response=response; self.headers={}; self.calls=[]
    def request(self, method, url, **kwargs): self.calls.append((method,url,kwargs)); return self.response

class WallexTests(unittest.TestCase):
    def test_auth_header_and_limit_order(self):
        s=FakeSession(FakeResponse(200,{"success":True,"result":{"status":"NEW"}}))
        c=WallexClient(WallexConfig("secret"),s)
        r=c.place_limit("BTCUSDT","BUY",100000,0.001,"grid-1")
        self.assertEqual(r["result"]["status"],"NEW")
        self.assertEqual(s.headers["X-API-Key"],"secret")
        self.assertEqual(s.calls[0][2]["json"]["client_id"],"grid-1")

    def test_read_balance(self):
        s=FakeSession(FakeResponse(200,{"success":True,"result":{"balances":{}}}))
        c=WallexClient(WallexConfig("k"),s)
        c.balances()
        self.assertEqual(s.calls[0][1],"https://api.wallex.ir/v1/account/balances")

    def test_api_error(self):
        s=FakeSession(FakeResponse(401,{"success":False,"message":"unauthorized"}))
        c=WallexClient(WallexConfig("k"),s)
        with self.assertRaises(WallexAPIError): c.balances()

    def test_no_withdraw_method(self):
        c=WallexClient(WallexConfig("k"),FakeSession(FakeResponse(200,{"success":True})))
        self.assertFalse(hasattr(c,"withdraw"))

if __name__ == "__main__": unittest.main()
