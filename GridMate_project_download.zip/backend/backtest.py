import csv
from dataclasses import dataclass
from typing import List, Dict

try:
    from .realistic_execution import RealisticExecutor
except ImportError:
    from realistic_execution import RealisticExecutor

@dataclass
class Bar:
    timestamp: str
    close: float

@dataclass
class OHLCBar:
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


def load_close_csv(path: str) -> List[Bar]:
    bars = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or 'timestamp' not in reader.fieldnames or 'close' not in reader.fieldnames:
            raise ValueError('CSV must contain timestamp and close columns')
        for row in reader:
            bars.append(Bar(row['timestamp'], float(row['close'])))
    if len(bars) < 2:
        raise ValueError('CSV needs at least 2 rows')
    return bars


def load_ohlcv_csv(path: str) -> List[OHLCBar]:
    bars = []
    required = {'timestamp', 'open', 'high', 'low', 'close'}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError('CSV must contain timestamp, open, high, low, close columns')
        for row in reader:
            o, h, l, c = map(float, (row['open'], row['high'], row['low'], row['close']))
            if l > h or l > min(o, c) or h < max(o, c):
                raise ValueError(f"Invalid OHLC row at {row['timestamp']}")
            bars.append(OHLCBar(row['timestamp'], o, h, l, c, float(row.get('volume') or 0)))
    if len(bars) < 2:
        raise ValueError('CSV needs at least 2 rows')
    return bars


class GridBacktester:
    def __init__(self, lower, upper, grids, quote_per_order, fee_rate=0.001,
                 max_quote=1000.0, stop_loss_pct=0.0, starting_quote=1000.0,
                 slippage_bps=5.0, min_notional=5.0, max_quote_per_order=None):
        if not lower < upper: raise ValueError('lower must be below upper')
        if grids < 2: raise ValueError('grids must be >= 2')
        if quote_per_order <= 0: raise ValueError('quote_per_order must be > 0')
        self.lower, self.upper, self.grids = lower, upper, grids
        self.quote_per_order = quote_per_order
        self.fee_rate = fee_rate
        self.max_quote = max_quote
        self.stop_loss_pct = stop_loss_pct
        self.starting_quote = starting_quote
        self.executor = RealisticExecutor(
            fee_rate=fee_rate, slippage_bps=slippage_bps,
            min_notional=min_notional,
            max_quote_per_order=max_quote_per_order or quote_per_order,
        )

    def _sell_at(self, market_price, reference_level, base, cash):
        requested_quote = min(self.quote_per_order, base * market_price)
        result = self.executor.execute('sell', market_price, requested_quote)
        if result is None:
            return base, cash, 0.0, 0.0, 0.0, 1
        qty = result.executed_quote / result.executed_price
        cash += result.executed_quote - result.fee
        base -= qty
        realized = (result.executed_price - reference_level) * qty - result.fee
        return base, cash, result.fee, result.slippage_cost, realized, 0

    def _buy_at(self, market_price, base, cash):
        requested_quote = self.quote_per_order
        if not (cash >= requested_quote + requested_quote*self.fee_rate and cash + base*market_price <= self.starting_quote+self.max_quote):
            return base, cash, 0.0, 0.0, 1
        result = self.executor.execute('buy', market_price, requested_quote)
        if result is None:
            return base, cash, 0.0, 0.0, 1
        total_cost = result.executed_quote + result.fee
        if total_cost > cash:
            return base, cash, 0.0, 0.0, 1
        qty = result.executed_quote / result.executed_price
        cash -= total_cost
        base += qty
        return base, cash, result.fee, result.slippage_cost, 0

    def _trade_crossings(self, start, end, levels, base, cash):
        fees = slip = realized = 0.0
        rejected = touched = trades = 0
        if end > start:
            crossed = [x for x in levels[1:-1] if start <= x < end]
            for level in crossed:
                touched += 1
                if base > 0:
                    base, cash, fee, s, rpnl, rej = self._sell_at(level, level, base, cash)
                    fees += fee; slip += s; realized += rpnl; rejected += rej
                    trades += int(rej == 0)
        elif end < start:
            crossed = [x for x in reversed(levels[1:-1]) if start >= x > end]
            for level in crossed:
                touched += 1
                base, cash, fee, s, rej = self._buy_at(level, base, cash)
                fees += fee; slip += s; rejected += rej
                trades += int(rej == 0)
        return base, cash, fees, slip, realized, rejected, touched, trades

    def run(self, bars) -> Dict:
        if len(bars) < 2: raise ValueError('bars needs at least 2 rows')
        levels = [self.lower + i*(self.upper-self.lower)/self.grids for i in range(self.grids+1)]
        cash, base = self.starting_quote, 0.0
        fees = realized = slippage_cost = 0.0
        trades = rejected_orders = touched_levels = 0
        peak, max_dd = self.starting_quote, 0.0
        stopped = False
        last_price = bars[0].close
        stop_price = self.lower * (1-self.stop_loss_pct) if self.stop_loss_pct > 0 else None

        for bar in bars:
            if isinstance(bar, OHLCBar):
                # Conservative deterministic intrabar path: nearer extreme first, then opposite extreme, then close.
                path = [bar.high, bar.low, bar.close] if abs(bar.high-last_price) <= abs(last_price-bar.low) else [bar.low, bar.high, bar.close]
                for target in path:
                    if stop_price is not None and target <= stop_price:
                        # Model liquidation at the stop threshold rather than silently using the close.
                        if base > 0:
                            requested = base * stop_price
                            result = self.executor.execute('sell', stop_price, requested)
                            if result is not None:
                                qty = result.executed_quote / result.executed_price
                                cash += result.executed_quote - result.fee
                                base -= qty
                                fees += result.fee; slippage_cost += result.slippage_cost; trades += 1
                        stopped = True
                        last_price = stop_price
                        break
                    base, cash, fee, slip, rpnl, rej, touched, tr = self._trade_crossings(last_price, target, levels, base, cash)
                    fees += fee; slippage_cost += slip; realized += rpnl
                    rejected_orders += rej; touched_levels += touched; trades += tr
                    last_price = target
                if stopped:
                    break
                p = bar.close
            else:
                p = bar.close
                if stop_price is not None and p <= stop_price:
                    if base > 0:
                        result = self.executor.execute('sell', stop_price, base * stop_price)
                        if result is not None:
                            qty = result.executed_quote / result.executed_price
                            cash += result.executed_quote - result.fee; base -= qty
                            fees += result.fee; slippage_cost += result.slippage_cost; trades += 1
                    stopped = True; last_price = stop_price; break
                base, cash, fee, slip, rpnl, rej, touched, tr = self._trade_crossings(last_price, p, levels, base, cash)
                fees += fee; slippage_cost += slip; realized += rpnl
                rejected_orders += rej; touched_levels += touched; trades += tr
                last_price = p

            equity = cash + base*p
            peak = max(peak, equity)
            max_dd = max(max_dd, (peak-equity)/peak if peak else 0)

        final_price = last_price if stopped else bars[-1].close
        equity = cash + base*final_price
        return {
            'starting_quote': round(self.starting_quote, 8), 'ending_equity': round(equity, 8),
            'return_pct': round((equity/self.starting_quote-1)*100, 4),
            'max_drawdown_pct': round(max_dd*100, 4), 'trades': trades,
            'rejected_orders': rejected_orders, 'touched_levels': touched_levels,
            'fees': round(fees, 8), 'slippage_cost': round(slippage_cost, 8),
            'realized_pnl': round(realized, 8), 'base_position': round(base, 8),
            'cash': round(cash, 8), 'stop_triggered': stopped, 'bars': len(bars),
            'slippage_bps': self.executor.slippage_bps, 'min_notional': self.executor.min_notional,
            'max_quote_per_order': self.executor.max_quote_per_order,
        }
