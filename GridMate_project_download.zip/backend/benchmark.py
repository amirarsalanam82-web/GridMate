from typing import Dict, List
try:
    from .backtest import OHLCBar, Bar
except ImportError:
    from backtest import OHLCBar, Bar


def buy_and_hold(bars: List[object], starting_quote: float = 1000.0) -> Dict:
    if len(bars) < 2:
        raise ValueError('bars needs at least 2 rows')
    first = bars[0].close
    last = bars[-1].close
    qty = starting_quote / first
    ending = qty * last
    ret = (ending / starting_quote - 1.0) * 100.0
    peak = starting_quote
    max_dd = 0.0
    for b in bars:
        equity = qty * b.close
        peak = max(peak, equity)
        max_dd = max(max_dd, (peak - equity) / peak if peak else 0.0)
    return {
        'starting_quote': round(starting_quote, 8),
        'ending_equity': round(ending, 8),
        'return_pct': round(ret, 4),
        'max_drawdown_pct': round(max_dd * 100, 4),
        'bars': len(bars),
    }


def compare(grid: Dict, hold: Dict) -> Dict:
    return {
        'grid_return_pct': grid['return_pct'],
        'buy_hold_return_pct': hold['return_pct'],
        'return_difference_pct_points': round(grid['return_pct'] - hold['return_pct'], 4),
        'grid_max_drawdown_pct': grid['max_drawdown_pct'],
        'buy_hold_max_drawdown_pct': hold['max_drawdown_pct'],
        'drawdown_difference_pct_points': round(grid['max_drawdown_pct'] - hold['max_drawdown_pct'], 4),
        'grid_ending_equity': grid['ending_equity'],
        'buy_hold_ending_equity': hold['ending_equity'],
    }
