from backtest import Bar, GridBacktester

def test_range():
    bars = [Bar(str(i), p) for i,p in enumerate([65000,64500,65500,64000,66000,64500,65500,65000])]
    r = GridBacktester(60000,70000,10,25,0.001,1000,0.08,1000,5,5,25).run(bars)
    assert r["ending_equity"] > 0
    assert r["fees"] >= 0
    assert r["slippage_cost"] >= 0

def test_downtrend():
    bars = [Bar(str(i), p) for i,p in enumerate([69000,68000,67000,66000,65000,64000,63000,62000,61000])]
    r = GridBacktester(60000,70000,10,25,0.001,1000,0.05,1000,5,5,25).run(bars)
    assert r["ending_equity"] > 0
    assert r["stop_triggered"] is False

def test_stop_loss():
    bars = [Bar(str(i), p) for i,p in enumerate([65000,64000,62000,58000,56000])]
    r = GridBacktester(60000,70000,10,25,0.001,1000,0.05,1000,5,5,25).run(bars)
    assert r["stop_triggered"] is True

def test_min_notional_rejection():
    bars = [Bar(str(i), p) for i,p in enumerate([65000,64000,66000,65000])]
    r = GridBacktester(60000,70000,10,4,0.001,1000,0.08,1000,5,5,4).run(bars)
    assert r["rejected_orders"] >= 0

def test_order_cap():
    bars = [Bar(str(i), p) for i,p in enumerate([65000,64000,66000,65000])]
    r = GridBacktester(60000,70000,10,50,0.001,1000,0.08,1000,5,5,25).run(bars)
    assert r["max_quote_per_order"] == 25

def run_all():
    test_range(); test_downtrend(); test_stop_loss(); test_min_notional_rejection(); test_order_cap()
    return "ALL INTEGRATED EXECUTION TESTS PASSED"

if __name__ == "__main__":
    print(run_all())
