import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from order_manager import OrderManager

def test_reconcile_open_orders():
    m=OrderManager()
    m.submit("c1","BTCUSDT","BUY",0.001,10000,lambda o: {"status":"NEW","clientOrderId":"c1"})
    m.submit("c2","BTCUSDT","SELL",0.001,11000,lambda o: {"status":"NEW","clientOrderId":"c2"})
    n=m.reconcile_many([{"clientOrderId":"c1","status":"PARTIALLY_FILLED"}])
    assert n==1
    assert m.orders["c1"].status=="PARTIALLY_FILLED"
    assert m.orders["c2"].status=="NEW"

def test_finalize_only_terminal():
    m=OrderManager()
    m.submit("c1","BTCUSDT","BUY",0.001,10000,lambda o: {"status":"NEW","clientOrderId":"c1"})
    m.finalize("c1","FILLED")
    assert m.orders["c1"].status=="FILLED"
    try: m.finalize("c1","NEW")
    except ValueError: pass
    else: raise AssertionError("non-terminal status accepted")

if __name__=="__main__":
    test_reconcile_open_orders(); test_finalize_only_terminal(); print("reconciliation tests passed")
