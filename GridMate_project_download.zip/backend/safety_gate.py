"""Live-trading safety gate for GridMate.

Paper/Dry-Run is always the default. Live mode requires an explicit,
out-of-band confirmation token in the process environment.
No withdrawal capability is exposed here.
"""
import os
from dataclasses import dataclass

LIVE_CONFIRMATION = "GRIDMATE_LIVE_CONFIRMATION"

@dataclass(frozen=True)
class TradingMode:
    name: str

    @property
    def is_live(self) -> bool:
        return self.name == "LIVE"

class SafetyGate:
    def __init__(self, mode: str = "PAPER"):
        normalized = str(mode or "PAPER").upper()
        if normalized not in {"PAPER", "LIVE"}:
            raise ValueError("mode must be PAPER or LIVE")
        self.mode = TradingMode(normalized)

    def authorize(self) -> None:
        if not self.mode.is_live:
            return
        token = os.getenv(LIVE_CONFIRMATION, "")
        if token != "I_UNDERSTAND_LIVE_TRADING":
            raise PermissionError(
                "LIVE mode is locked. Set GRIDMATE_LIVE_CONFIRMATION="
                "'I_UNDERSTAND_LIVE_TRADING' out-of-band."
            )

    def can_place_orders(self) -> bool:
        try:
            self.authorize()
            return True
        except PermissionError:
            return False
