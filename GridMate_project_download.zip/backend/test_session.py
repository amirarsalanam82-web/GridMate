import os, tempfile
from state_store import StateStore
from order_manager import OrderManager
from grid_runner import GridRunner
from recovery import RecoveryCoordinator
from session import SessionCoordinator

class Ex:
    def reconcile_open_orders(self, manager, symbol=None): return 0
    def order(self, client_id): return {'result': {'clientOrderId': client_id, 'status': 'FILLED'}}
    def normalize_order(self, payload): return payload['result']

def test_recovery_required_before_start():
    m=OrderManager(max_order_quote=20); r=GridRunner('BTCUSDT',90,110,4,10,m)
    s=SessionCoordinator(r, RecoveryCoordinator(m,Ex()), heartbeat_timeout=5)
    out=s.recover_and_start('BTCUSDT')
    assert out['safe_to_run'] and r.running

def test_stale_market_stops_runner():
    m=OrderManager(); r=GridRunner('BTCUSDT',90,110,4,10,m)
    s=SessionCoordinator(r, RecoveryCoordinator(m,Ex()), heartbeat_timeout=5)
    s.recover_and_start('BTCUSDT'); s.on_market_price(100, timestamp=100)
    out=s.watchdog(now=106)
    assert out['stale'] and not r.running and not out['connected']

def test_session_state_persists():
    fd,path=tempfile.mkstemp(); os.close(fd)
    try:
        st=StateStore(path); m=OrderManager(store=st); r=GridRunner('BTCUSDT',90,110,4,10,m)
        s=SessionCoordinator(r, RecoveryCoordinator(m,Ex()), store=st)
        s.on_market_price(100, timestamp=123)
        st.close()
        st2=StateStore(path); m2=OrderManager(store=st2); r2=GridRunner('BTCUSDT',90,110,4,10,m2)
        s2=SessionCoordinator(r2, RecoveryCoordinator(m2,Ex()), store=st2)
        assert s2.last_market_ts == 123
        st2.close()
    finally:
        if os.path.exists(path): os.unlink(path)

if __name__=='__main__':
    test_recovery_required_before_start(); test_stale_market_stops_runner(); test_session_state_persists(); print('session tests passed')
