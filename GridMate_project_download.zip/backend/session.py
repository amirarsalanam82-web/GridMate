"""Persistent runner/session coordinator for safe continuous operation.

The coordinator keeps the bot stopped until recovery succeeds. It also applies
an explicit heartbeat timeout so stale market data cannot drive new orders.
"""
import time
from typing import Any, Dict

class SessionCoordinator:
    def __init__(self, runner, recovery, store=None, heartbeat_timeout=30.0):
        if heartbeat_timeout <= 0:
            raise ValueError("heartbeat_timeout must be positive")
        self.runner = runner
        self.recovery = recovery
        self.store = store
        self.heartbeat_timeout = float(heartbeat_timeout)
        self.last_market_ts = None
        self.connected = False
        self.last_recovery = None
        self._restore()

    def _restore(self):
        if not self.store:
            return
        self.connected = bool(self.store.load_state("session_connected", False))
        self.last_market_ts = self.store.load_state("last_market_ts", None)

    def _persist(self):
        if self.store:
            self.store.save_state("session_connected", self.connected)
            self.store.save_state("last_market_ts", self.last_market_ts)

    def recover_and_start(self, symbol=None) -> Dict[str, Any]:
        # Recovery must happen before the runner is allowed to submit anything.
        self.runner.stop()
        result = self.recovery.recover(symbol)
        self.last_recovery = result
        if not result.get("safe_to_run"):
            self.connected = False
            self._persist()
            return result
        self.connected = True
        self.runner.start()
        self._persist()
        return result

    def on_market_price(self, price, timestamp=None):
        now = time.time() if timestamp is None else float(timestamp)
        self.last_market_ts = now
        self.connected = True
        self._persist()
        return self.runner.on_price(price)

    def mark_disconnected(self):
        self.connected = False
        self.runner.stop()
        self._persist()

    def watchdog(self, now=None) -> Dict[str, Any]:
        now = time.time() if now is None else float(now)
        stale = self.last_market_ts is None or (now - self.last_market_ts > self.heartbeat_timeout)
        if stale:
            self.connected = False
            self.runner.stop()
            self._persist()
        return {"connected": self.connected, "stale": stale,
                "last_market_ts": self.last_market_ts,
                "runner_running": self.runner.running}
