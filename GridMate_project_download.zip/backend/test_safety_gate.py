import os
import unittest
from safety_gate import SafetyGate

class SafetyGateTests(unittest.TestCase):
    def test_paper_is_allowed(self):
        self.assertTrue(SafetyGate("PAPER").can_place_orders())

    def test_live_locked_by_default(self):
        os.environ.pop("GRIDMATE_LIVE_CONFIRMATION", None)
        self.assertFalse(SafetyGate("LIVE").can_place_orders())

    def test_live_requires_exact_confirmation(self):
        os.environ["GRIDMATE_LIVE_CONFIRMATION"] = "wrong"
        self.assertFalse(SafetyGate("LIVE").can_place_orders())
        os.environ["GRIDMATE_LIVE_CONFIRMATION"] = "I_UNDERSTAND_LIVE_TRADING"
        self.assertTrue(SafetyGate("LIVE").can_place_orders())
        os.environ.pop("GRIDMATE_LIVE_CONFIRMATION", None)

if __name__ == "__main__":
    unittest.main()
