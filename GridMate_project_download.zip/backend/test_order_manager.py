from .order_manager import OrderManager

def test_idempotent_submit():
    m=OrderManager(max_order_quote=100)
    calls=[]
    fn=lambda o: calls.append(o.client_id) or {"orderId":123,"status":"NEW"}
    a=m.submit("g1","BTCUSDT","BUY",0.001,50,fn)
    b=m.submit("g1","BTCUSDT","BUY",0.001,50,fn)
    assert a is b and calls == ["g1"]

def test_kill_switch_blocks_new_orders():
    m=OrderManager()
    m.activate_kill_switch()
    try: m.submit("g1","BTCUSDT","BUY",1,10,lambda o: {})
    except RuntimeError: return
    assert False

def test_limits_and_reconcile():
    m=OrderManager(max_open_orders=1,max_order_quote=20)
    o=m.submit("g1","BTCUSDT","BUY",1,10,lambda x:{"orderId":7,"status":"NEW"})
    assert o.exchange_id=="7"
    m.reconcile("g1","FILLED")
    assert len(m.open_orders())==0

def test_oversize_rejected():
    m=OrderManager(max_order_quote=20)
    try: m.submit("g1","BTCUSDT","BUY",3,10,lambda x:{})
    except ValueError: return
    assert False
