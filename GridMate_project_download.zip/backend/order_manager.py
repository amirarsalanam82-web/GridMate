"""Safe demo order lifecycle manager.

The manager is exchange-agnostic and deliberately does not implement withdrawals.
It provides idempotency, kill-switch behavior, local state reconciliation, and
protective limits before an exchange adapter is called.
"""
from dataclasses import dataclass, field
from typing import Dict, Optional, Callable, Any
import time

@dataclass
class ManagedOrder:
    client_id: str
    symbol: str
    side: str
    quantity: float
    price: float
    status: str = "NEW"
    exchange_id: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

class OrderManager:
    def __init__(self, max_open_orders=20, max_order_quote=100.0, store=None):
        if max_open_orders < 1 or max_order_quote <= 0:
            raise ValueError("invalid safety limits")
        self.max_open_orders = max_open_orders
        self.max_order_quote = max_order_quote
        self.kill_switch = False
        self.orders: Dict[str, ManagedOrder] = {}
        self.last_error = None
        self.store = store
        if self.store:
            self._restore()

    def _persist(self, order: ManagedOrder):
        if self.store:
            self.store.save_order(order.__dict__.copy())

    def _restore(self):
        for item in self.store.load_orders():
            try:
                self.orders[item["client_id"]] = ManagedOrder(**item)
            except TypeError:
                continue
        self.kill_switch = bool(self.store.load_state("kill_switch", False))

    def activate_kill_switch(self, cancel_fn: Optional[Callable[[ManagedOrder], Any]] = None):
        self.kill_switch = True
        for order in list(self.open_orders()):
            if cancel_fn:
                try:
                    cancel_fn(order)
                except Exception as exc:
                    self.last_error = str(exc)
            order.status = "CANCEL_REQUESTED"
            order.updated_at = time.time()
            self._persist(order)
        if self.store:
            self.store.save_state("kill_switch", True)

    def clear_kill_switch(self):
        self.kill_switch = False
        if self.store:
            self.store.save_state("kill_switch", False)

    def open_orders(self):
        return [o for o in self.orders.values() if o.status in {"NEW", "PARTIALLY_FILLED", "CANCEL_REQUESTED"}]

    def submit(self, client_id, symbol, side, quantity, price, submit_fn: Callable[[ManagedOrder], Any]):
        if self.kill_switch:
            raise RuntimeError("kill switch is active")
        if client_id in self.orders:
            return self.orders[client_id]
        if len(self.open_orders()) >= self.max_open_orders:
            raise RuntimeError("max open orders reached")
        quote = float(quantity) * float(price)
        if quote <= 0 or quote > self.max_order_quote:
            raise ValueError("order exceeds max quote safety limit")
        order = ManagedOrder(client_id, symbol.upper(), side.upper(), float(quantity), float(price))
        try:
            response = submit_fn(order)
            if isinstance(response, dict):
                order.exchange_id = str(response.get("orderId")) if response.get("orderId") is not None else None
                order.status = str(response.get("status", "NEW"))
            else:
                order.status = "SUBMITTED"
        except Exception as exc:
            order.status = "ERROR"
            self.last_error = str(exc)
            raise
        order.updated_at = time.time()
        self.orders[client_id] = order
        self._persist(order)
        return order

    def reconcile(self, client_id, exchange_status: str):
        if client_id not in self.orders:
            raise KeyError(client_id)
        self.orders[client_id].status = exchange_status.upper()
        self.orders[client_id].updated_at = time.time()
        self._persist(self.orders[client_id])
        return self.orders[client_id]

    def reconcile_many(self, exchange_orders, *, id_key="clientOrderId"):
        """Reconcile all locally known orders against an exchange open-order snapshot.

        Orders absent from the exchange open-order list are not blindly marked FILLED:
        the caller should supply final statuses for those orders through ``finalize``.
        This method only updates orders present in the exchange snapshot.
        """
        updated = 0
        for item in exchange_orders or []:
            cid = item.get(id_key) or item.get("client_id")
            if not cid or cid not in self.orders:
                continue
            status = str(item.get("status", "UNKNOWN")).upper()
            order = self.orders[cid]
            order.status = status
            order.exchange_id = str(item.get("orderId") or item.get("clientOrderId") or cid)
            order.updated_at = time.time()
            self._persist(order)
            updated += 1
        return updated

    def finalize(self, client_id, status):
        """Set a terminal exchange-confirmed status after an explicit order lookup."""
        if client_id not in self.orders:
            raise KeyError(client_id)
        status = str(status).upper()
        if status not in {"FILLED", "CANCELED", "REJECTED", "EXPIRED", "ERROR"}:
            raise ValueError("status is not terminal")
        return self.reconcile(client_id, status)

    def snapshot(self):
        return {
            "kill_switch": self.kill_switch,
            "open_orders": len(self.open_orders()),
            "orders": [o.__dict__.copy() for o in self.orders.values()],
            "last_error": self.last_error,
        }
