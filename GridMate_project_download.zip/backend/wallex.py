"""Wallex spot API adapter.

Read-only market/account methods and LIMIT order lifecycle are supported.
Withdrawals are intentionally not implemented.
"""
from dataclasses import dataclass
from typing import Any, Dict, Optional
import requests
import time
from threading import Lock

BASE_URL = "https://api.wallex.ir"

@dataclass
class WallexConfig:
    api_key: str
    base_url: str = BASE_URL
    timeout: float = 10.0
    min_request_interval: float = 0.12  # ~8.3 req/s, below the documented 10 req/s order limit

class WallexAPIError(RuntimeError):
    pass

class WallexClient:
    def __init__(self, config: WallexConfig, session: Optional[requests.Session] = None):
        if not config.api_key:
            raise ValueError("api_key is required")
        self.config = config
        self.session = session or requests.Session()
        self.session.headers.update({"X-API-Key": config.api_key, "Accept": "application/json"})
        self._rate_lock = Lock()
        self._last_request_at = 0.0

    def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        kwargs.setdefault("timeout", self.config.timeout)
        # Never automatically retry an order-placement request: after a timeout the exchange
        # may have accepted it, and retrying could duplicate the trade.
        with self._rate_lock:
            wait = self.config.min_request_interval - (time.monotonic() - self._last_request_at)
            if wait > 0:
                time.sleep(wait)
            self._last_request_at = time.monotonic()
        response = self.session.request(method, self.config.base_url.rstrip("/") + path, **kwargs)
        try:
            data = response.json()
        except ValueError as exc:
            raise WallexAPIError(f"non-JSON response: HTTP {response.status_code}") from exc
        if response.status_code >= 400 or data.get("success") is False:
            raise WallexAPIError(data.get("message") or f"HTTP {response.status_code}")
        return data

    def markets(self) -> Dict[str, Any]:
        return self._request("GET", "/v1/markets")

    def depth(self, symbol: str) -> Dict[str, Any]:
        return self._request("GET", "/v1/depth", params={"symbol": symbol.upper()})

    def balances(self) -> Dict[str, Any]:
        return self._request("GET", "/v1/account/balances")

    def fees(self) -> Dict[str, Any]:
        return self._request("GET", "/v1/account/fee")

    def open_orders(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        params = {"symbol": symbol.upper()} if symbol else None
        return self._request("GET", "/v1/account/openOrders", params=params)

    def order(self, client_order_id: str) -> Dict[str, Any]:
        return self._request("GET", f"/v1/account/orders/{client_order_id}")

    def place_limit(self, symbol: str, side: str, price: float, quantity: float, client_id: Optional[str] = None) -> Dict[str, Any]:
        payload = {
            "symbol": symbol.upper(), "type": "LIMIT", "side": side.upper(),
            "price": str(price), "quantity": str(quantity),
        }
        if client_id:
            payload["client_id"] = client_id
        return self._request("POST", "/v1/account/orders", json=payload)

    def cancel(self, client_order_id: str) -> Dict[str, Any]:
        return self._request("DELETE", "/v1/account/orders", params={"clientOrderId": client_order_id})

    def normalize_order(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Return the stable fields used by OrderManager from a Wallex response."""
        result = payload.get("result", payload)
        return {
            "clientOrderId": result.get("clientOrderId"),
            "status": str(result.get("status", "UNKNOWN")).upper(),
            "symbol": result.get("symbol"),
            "side": result.get("side"),
            "executedQty": result.get("executedQty"),
            "executedPercent": result.get("executedPercent"),
        }

    def reconcile_open_orders(self, manager, symbol: Optional[str] = None) -> int:
        """Sync locally tracked orders with Wallex open orders."""
        payload = self.open_orders(symbol)
        result = payload.get("result", {})
        orders = result.get("orders", result if isinstance(result, list) else [])
        return manager.reconcile_many(orders)

    def account_trades(self, symbol: Optional[str] = None, side: Optional[str] = None) -> Dict[str, Any]:
        params = {}
        if symbol: params["symbol"] = symbol.upper()
        if side: params["side"] = side.upper()
        return self._request("GET", "/v1/account/trades", params=params or None)
