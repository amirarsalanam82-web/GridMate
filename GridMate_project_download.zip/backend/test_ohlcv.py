import csv, tempfile, os
from backtest import OHLCBar, GridBacktester, load_ohlcv_csv

def test_ohlc_loader_and_validation():
    fd, path = tempfile.mkstemp(suffix='.csv'); os.close(fd)
    try:
        with open(path, 'w', newline='', encoding='utf-8') as f:
            w=csv.writer(f); w.writerow(['timestamp','open','high','low','close','volume']); w.writerow(['1',100,110,90,105,2]); w.writerow(['2',105,115,95,100,3])
        bars=load_ohlcv_csv(path)
        assert len(bars)==2 and bars[0].high==110
    finally: os.remove(path)

def test_ohlc_backtest_runs():
    bars=[OHLCBar(str(i),o,h,l,c,100) for i,(o,h,l,c) in enumerate([(100,105,95,102),(102,112,98,108),(108,115,90,100),(100,110,94,105)])]
    r=GridBacktester(90,120,6,10,0.001,1000,0.1,1000,5,5,10).run(bars)
    assert r['bars']==4 and r['ending_equity']>0 and r['touched_levels']>=0

def test_ohlc_stop_uses_low():
    bars=[OHLCBar('0',100,102,99,101), OHLCBar('1',101,103,85,102)]
    r=GridBacktester(90,110,4,10,0.001,1000,0.05,1000,5,5,10).run(bars)
    assert r['stop_triggered'] is True

def run_all():
    test_ohlc_loader_and_validation(); test_ohlc_backtest_runs(); test_ohlc_stop_uses_low(); return 'ALL OHLC TESTS PASSED'

if __name__=='__main__': print(run_all())
