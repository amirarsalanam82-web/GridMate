import hashlib, hmac, os, urllib.parse
from .binance_demo import BinanceDemoClient, DEMO_BASE

def test_demo_endpoint_default():
    assert DEMO_BASE == "https://demo-api.binance.com/api"

def test_signature_is_deterministic():
    secret = "secret"
    query = urllib.parse.urlencode({"symbol":"BTCUSDT","timestamp":123})
    sig = hmac.new(secret.encode(), query.encode(), hashlib.sha256).hexdigest()
    assert len(sig) == 64

def test_missing_credentials_rejected(monkeypatch):
    monkeypatch.delenv("GRIDMATE_BINANCE_API_KEY", raising=False)
    monkeypatch.delenv("GRIDMATE_BINANCE_API_SECRET", raising=False)
    try:
        BinanceDemoClient()
        assert False
    except ValueError:
        assert True
