"""Minimal Binance Spot Demo Mode REST client.

Safety defaults: demo endpoint only; withdrawals are not implemented.
API keys are read from environment variables and never stored in source.
"""
import hashlib, hmac, os, time, urllib.parse, urllib.request, json

DEMO_BASE = "https://demo-api.binance.com/api"

class BinanceDemoClient:
    def __init__(self, api_key=None, api_secret=None, base_url=DEMO_BASE, timeout=15):
        self.api_key = api_key or os.getenv("GRIDMATE_BINANCE_API_KEY")
        self.api_secret = api_secret or os.getenv("GRIDMATE_BINANCE_API_SECRET")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        if not self.api_key or not self.api_secret:
            raise ValueError("Demo API credentials are required via environment variables")

    def _request(self, method, path, params=None, signed=False):
        params = dict(params or {})
        if signed:
            params.setdefault("timestamp", int(time.time() * 1000))
            query = urllib.parse.urlencode(params, doseq=True)
            sig = hmac.new(self.api_secret.encode(), query.encode(), hashlib.sha256).hexdigest()
            query += "&signature=" + sig
        else:
            query = urllib.parse.urlencode(params, doseq=True)
        url = self.base_url + path + (("?" + query) if query else "")
        req = urllib.request.Request(url, method=method.upper())
        req.add_header("X-MBX-APIKEY", self.api_key)
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def account(self):
        return self._request("GET", "/v3/account", signed=True)

    def ticker_price(self, symbol):
        return self._request("GET", "/v3/ticker/price", {"symbol": symbol.upper()})

    def exchange_info(self, symbol=None):
        params = {"symbol": symbol.upper()} if symbol else {}
        return self._request("GET", "/v3/exchangeInfo", params)

    def place_limit_order(self, symbol, side, quantity, price, time_in_force="GTC"):
        # Intentionally only LIMIT orders in this first demo adapter.
        params = {
            "symbol": symbol.upper(), "side": side.upper(), "type": "LIMIT",
            "timeInForce": time_in_force, "quantity": quantity, "price": price,
            "newOrderRespType": "RESULT",
        }
        return self._request("POST", "/v3/order", params, signed=True)

    def cancel_order(self, symbol, order_id):
        return self._request("DELETE", "/v3/order", {"symbol": symbol.upper(), "orderId": order_id}, signed=True)
