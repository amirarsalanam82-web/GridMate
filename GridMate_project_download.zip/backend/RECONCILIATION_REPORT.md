# GridMate v0.4.3 — Reconciliation

This release adds explicit exchange-state reconciliation.

- `OrderManager.reconcile_many()` updates locally tracked orders only when the exchange reports them.
- Missing orders are deliberately **not** assumed filled; a terminal lookup is required before finalizing.
- `OrderManager.finalize()` accepts only terminal statuses.
- `WallexClient.reconcile_open_orders()` connects the Wallex open-order snapshot to the manager.
- No withdrawal endpoint is implemented.

This design reduces duplicate orders after restarts or network interruptions.
