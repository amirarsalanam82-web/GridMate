"""Small SQLite state store for crash/restart recovery.

No secrets are persisted here. Only bot configuration and order lifecycle state.
"""
import json
import sqlite3
import threading
import time
from typing import Dict, List, Optional

class StateStore:
    def __init__(self, path: str = 'gridmate_state.sqlite3'):
        self.path = path
        self._lock = threading.Lock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.execute('PRAGMA journal_mode=WAL')
        self.conn.execute('''CREATE TABLE IF NOT EXISTS orders (
            client_id TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            updated_at REAL NOT NULL
        )''')
        self.conn.execute('''CREATE TABLE IF NOT EXISTS bot_state (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at REAL NOT NULL
        )''')
        self.conn.commit()

    def save_order(self, order: Dict):
        now = time.time()
        with self._lock:
            self.conn.execute('INSERT OR REPLACE INTO orders(client_id,payload,updated_at) VALUES(?,?,?)',
                              (order['client_id'], json.dumps(order), now))
            self.conn.commit()

    def load_orders(self) -> List[Dict]:
        with self._lock:
            rows = self.conn.execute('SELECT payload FROM orders ORDER BY updated_at').fetchall()
        return [json.loads(r[0]) for r in rows]

    def save_state(self, key: str, value):
        now = time.time()
        with self._lock:
            self.conn.execute('INSERT OR REPLACE INTO bot_state(key,value,updated_at) VALUES(?,?,?)',
                              (key, json.dumps(value), now))
            self.conn.commit()

    def load_state(self, key: str, default=None):
        with self._lock:
            row = self.conn.execute('SELECT value FROM bot_state WHERE key=?', (key,)).fetchone()
        return default if row is None else json.loads(row[0])

    def clear(self):
        with self._lock:
            self.conn.execute('DELETE FROM orders')
            self.conn.execute('DELETE FROM bot_state')
            self.conn.commit()

    def close(self):
        self.conn.close()
