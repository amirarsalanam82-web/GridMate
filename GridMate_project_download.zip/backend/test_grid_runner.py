from order_manager import OrderManager
from grid_runner import GridRunner

def test_dry_run_crossing():
    m = OrderManager(max_open_orders=5, max_order_quote=20)
    r = GridRunner("BTCUSDT", 90, 110, 4, 10, m, dry_run=True)
    r.start(); r.on_price(105); events = r.on_price(99)
    assert events and events[0]["mode"] == "DRY_RUN"
    assert m.snapshot()["open_orders"] == 0

def test_kill_switch_blocks_start():
    m = OrderManager(); m.activate_kill_switch()
    r = GridRunner("BTCUSDT", 90, 110, 4, 10, m)
    try:
        r.start(); assert False
    except RuntimeError:
        pass

def test_live_requires_callback():
    m = OrderManager(max_order_quote=20)
    r = GridRunner("BTCUSDT", 90, 110, 4, 10, m, dry_run=False)
    r.start(); r.on_price(105); r.on_price(99)
    assert r.last_error == "live mode requires submit_fn"

if __name__ == '__main__':
    test_dry_run_crossing(); test_kill_switch_blocks_start(); test_live_requires_callback(); print('grid runner tests passed')
