from dataclasses import dataclass

@dataclass
class ExecutionResult:
    side: str
    requested_quote: float
    executed_quote: float
    executed_price: float
    fee: float
    slippage_cost: float

class RealisticExecutor:
    """Conservative paper execution model for backtests."""
    def __init__(self, fee_rate=0.001, slippage_bps=5.0,
                 min_notional=5.0, max_quote_per_order=25.0):
        if fee_rate < 0 or slippage_bps < 0 or min_notional < 0 or max_quote_per_order <= 0:
            raise ValueError("invalid execution parameters")
        self.fee_rate = fee_rate
        self.slippage_bps = slippage_bps
        self.min_notional = min_notional
        self.max_quote_per_order = max_quote_per_order

    def execute(self, side, price, requested_quote):
        if side not in ("buy", "sell"):
            raise ValueError("side must be buy or sell")
        if price <= 0 or requested_quote <= 0:
            raise ValueError("price and requested_quote must be > 0")
        if requested_quote < self.min_notional:
            return None
        quote = min(requested_quote, self.max_quote_per_order)
        slip = self.slippage_bps / 10000.0
        exec_price = price * (1 + slip if side == "buy" else 1 - slip)
        fee = quote * self.fee_rate
        qty = quote / exec_price
        slippage_cost = abs(exec_price - price) * qty
        return ExecutionResult(side, requested_quote, quote, exec_price, fee, slippage_cost)
