import os, tempfile
from order_manager import OrderManager
from state_store import StateStore
from recovery import RecoveryCoordinator

class FakeExchange:
    def __init__(self, status='FILLED', fail=False): self.status=status; self.fail=fail
    def reconcile_open_orders(self, manager, symbol=None): return 0
    def order(self, client_id):
        if self.fail: raise RuntimeError('network down')
        return {'result': {'clientOrderId': client_id, 'status': self.status}}
    def normalize_order(self, payload):
        r=payload['result']; return {'clientOrderId': r['clientOrderId'], 'status': r['status']}

def test_persistence_restore():
    fd,path=tempfile.mkstemp(); os.close(fd)
    try:
        s=StateStore(path); m=OrderManager(max_order_quote=20, store=s)
        m.submit('c1','BTCUSDT','BUY',0.1,100,lambda o:{'orderId':'x1','status':'NEW'})
        m2=OrderManager(max_order_quote=20, store=StateStore(path))
        assert 'c1' in m2.orders and m2.orders['c1'].exchange_id == 'x1'
    finally:
        try: s.close()
        except: pass
        os.unlink(path)

def test_recovery_terminal():
    s=StateStore(':memory:'); m=OrderManager(max_order_quote=20, store=s)
    m.submit('c1','BTCUSDT','BUY',0.1,100,lambda o:{'orderId':'x1','status':'NEW'})
    r=RecoveryCoordinator(m, FakeExchange('FILLED')).recover('BTCUSDT')
    assert r['safe_to_run'] and m.orders['c1'].status == 'FILLED'

def test_recovery_uncertain_is_not_safe():
    s=StateStore(':memory:'); m=OrderManager(max_order_quote=20, store=s)
    m.submit('c1','BTCUSDT','BUY',0.1,100,lambda o:{'orderId':'x1','status':'NEW'})
    r=RecoveryCoordinator(m, FakeExchange(fail=True)).recover('BTCUSDT')
    assert not r['safe_to_run'] and r['uncertain']

if __name__=='__main__':
    test_persistence_restore(); test_recovery_terminal(); test_recovery_uncertain_is_not_safe(); print('recovery v0.4.5 tests passed')
