from backtest import OHLCBar, GridBacktester

def test_grid_fills_at_crossed_level():
    bars=[OHLCBar('0',100,110,100,105), OHLCBar('1',105,125,105,120)]
    r=GridBacktester(90,130,4,10,fee_rate=0.0,slippage_bps=0,min_notional=1,max_quote_per_order=10).run(bars)
    assert r['touched_levels'] >= 1

def test_stop_liquidates():
    bars=[OHLCBar('0',100,102,99,101), OHLCBar('1',101,103,80,102)]
    r=GridBacktester(90,110,4,10,fee_rate=0.0,slippage_bps=0,min_notional=1,max_quote_per_order=10,stop_loss_pct=0.05,starting_quote=1000).run(bars)
    assert r['stop_triggered'] is True

def run_all():
    test_grid_fills_at_crossed_level(); test_stop_liquidates(); return 'ALL v0.3.8 TESTS PASSED'
if __name__=='__main__': print(run_all())
