from .backtest import OHLCBar
from .benchmark import buy_and_hold, compare

def test_buy_hold_flat():
    bars=[OHLCBar('1',100,101,99,100), OHLCBar('2',100,101,99,100)]
    r=buy_and_hold(bars,1000)
    assert r['return_pct']==0.0

def test_buy_hold_up():
    bars=[OHLCBar('1',100,110,95,100), OHLCBar('2',120,125,115,120)]
    r=buy_and_hold(bars,1000)
    assert r['return_pct']==20.0

def test_compare():
    g={'return_pct':5.0,'max_drawdown_pct':3.0,'ending_equity':1050}
    h={'return_pct':8.0,'max_drawdown_pct':6.0,'ending_equity':1080}
    r=compare(g,h)
    assert r['return_difference_pct_points']==-3.0
    assert r['drawdown_difference_pct_points']==-3.0
