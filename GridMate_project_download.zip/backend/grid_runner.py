"""Conservative grid runner with dry-run mode.

The runner never places real orders unless an explicit live submit callback is
provided. It uses market snapshots, safety limits, and an OrderManager.
"""
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional
import time

@dataclass
class GridLevel:
    price: float
    side: str

class GridRunner:
    def __init__(self, symbol: str, lower: float, upper: float, grids: int,
                 quote_per_order: float, manager, dry_run: bool = True):
        if lower <= 0 or upper <= lower or grids < 2 or quote_per_order <= 0:
            raise ValueError("invalid grid configuration")
        self.symbol = symbol.upper()
        self.lower, self.upper, self.grids = float(lower), float(upper), int(grids)
        self.quote_per_order = float(quote_per_order)
        self.manager = manager
        self.dry_run = bool(dry_run)
        self.running = False
        self.last_price: Optional[float] = None
        self.last_error: Optional[str] = None
        step = (self.upper - self.lower) / self.grids
        self.levels = [self.lower + i * step for i in range(self.grids + 1)]
        self.triggered = set()

    def start(self):
        if self.manager.kill_switch:
            raise RuntimeError("kill switch is active")
        self.running = True

    def stop(self):
        self.running = False

    def reset(self):
        self.running = False
        self.last_price = None
        self.last_error = None
        self.triggered.clear()

    def _candidate_orders(self, price: float) -> List[GridLevel]:
        # Conservative trigger: only act when price crosses a grid level.
        if self.last_price is None:
            return []
        out = []
        for i, level in enumerate(self.levels[1:-1], start=1):
            key = (i, "BUY")
            if self.last_price > level >= price and key not in self.triggered:
                out.append(GridLevel(level, "BUY")); self.triggered.add(key)
            key = (i, "SELL")
            if self.last_price < level <= price and key not in self.triggered:
                out.append(GridLevel(level, "SELL")); self.triggered.add(key)
        return out

    def on_price(self, price: float, submit_fn: Optional[Callable] = None) -> List[Dict]:
        price = float(price)
        if price <= 0:
            raise ValueError("price must be positive")
        if not self.running:
            self.last_price = price
            return []
        events = []
        for candidate in self._candidate_orders(price):
            qty = self.quote_per_order / candidate.price
            cid = f"grid-{self.symbol}-{candidate.side}-{candidate.price:.12f}"
            if self.dry_run:
                events.append({"mode":"DRY_RUN", "client_id":cid, "side":candidate.side,
                               "price":candidate.price, "quantity":qty})
                continue
            if submit_fn is None:
                self.last_error = "live mode requires submit_fn"
                continue
            try:
                order = self.manager.submit(cid, self.symbol, candidate.side, qty,
                                             candidate.price, submit_fn)
                events.append(order.__dict__.copy())
            except Exception as exc:
                self.last_error = str(exc)
        self.last_price = price
        return events

    def snapshot(self):
        return {"symbol": self.symbol, "running": self.running,
                "dry_run": self.dry_run, "last_price": self.last_price,
                "levels": self.levels, "last_error": self.last_error,
                "manager": self.manager.snapshot()}
