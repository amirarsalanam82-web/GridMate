
from backtest import Bar, GridBacktester

def run(name, prices, stop=0.08):
    bars = [Bar(str(i), float(p)) for i,p in enumerate(prices)]
    r = GridBacktester(
        lower=60000, upper=70000, grids=20,
        quote_per_order=25, fee_rate=0.001,
        max_quote=1000, stop_loss_pct=stop,
        starting_quote=1000
    ).run(bars)
    print(name, r)
    assert r["ending_equity"] > 0
    assert r["fees"] >= 0
    assert r["trades"] >= 0
    return r

def main():
    cases = {
        "flat": [65000]*100,
        "range": [65000 + (i%20-10)*450 for i in range(200)],
        "uptrend": [61000 + i*45 for i in range(220)],
        "downtrend": [69000 - i*45 for i in range(220)],
        "sharp_drop": [68000, 67000, 66000, 64000, 62000, 59000, 55000, 52000],
        "volatile": [65000, 69000, 62000, 68000, 61000, 67000, 60000, 66000]*30,
    }
    results = {name: run(name, prices) for name, prices in cases.items()}
    assert results["sharp_drop"]["stop_triggered"] is True
    print("ALL STRESS CASES PASSED")
    return results

if __name__ == "__main__":
    main()
