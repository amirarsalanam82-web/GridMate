from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .backtest import load_close_csv, load_ohlcv_csv, GridBacktester
from .order_manager import OrderManager

app = FastAPI(title='GridMate v0.4.2')
manager = OrderManager(max_open_orders=20, max_order_quote=100.0)

class BacktestRequest(BaseModel):
    csv_path: str = '../sample_data/sample_btc.csv'
    data_format: str = 'auto'
    lower_price: float = 60000
    upper_price: float = 70000
    grids: int = 20
    quote_per_order: float = 25
    fee_rate: float = 0.001
    max_quote: float = 1000
    stop_loss_pct: float = 0.08
    starting_quote: float = 1000
    slippage_bps: float = 5
    min_notional: float = 5
    max_quote_per_order: float = 25

@app.get('/health')
def health(): return {'ok': True, 'version': '0.4.2'}

@app.get('/status')
def status(): return manager.snapshot()

@app.post('/start')
def start():
    if manager.kill_switch: raise HTTPException(409, 'kill switch is active')
    return {'running': True, 'kill_switch': False}

@app.post('/stop')
def stop():
    manager.activate_kill_switch()
    return {'running': False, 'kill_switch': True}

@app.post('/reset')
def reset():
    manager.orders.clear(); manager.last_error=None; manager.clear_kill_switch()
    return {'ok': True, 'running': False, 'kill_switch': False}

@app.post('/backtest')
def backtest(req: BacktestRequest):
    try:
        if req.data_format == 'ohlcv': bars = load_ohlcv_csv(req.csv_path)
        elif req.data_format == 'close': bars = load_close_csv(req.csv_path)
        else:
            try: bars = load_ohlcv_csv(req.csv_path)
            except Exception: bars = load_close_csv(req.csv_path)
        engine = GridBacktester(req.lower_price, req.upper_price, req.grids, req.quote_per_order,
            req.fee_rate, req.max_quote, req.stop_loss_pct, req.starting_quote,
            req.slippage_bps, req.min_notional, req.max_quote_per_order)
        return engine.run(bars)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
