
from realistic_execution import RealisticExecutor

def main():
    ex = RealisticExecutor(fee_rate=0.001, slippage_bps=10, min_notional=5, max_quote_per_order=25)

    buy = ex.execute("buy", 65000, 25)
    assert buy is not None
    assert buy.executed_quote == 25
    assert buy.fee > 0
    assert buy.slippage_cost > 0

    sell = ex.execute("sell", 65000, 25)
    assert sell is not None
    assert sell.fee > 0
    assert sell.slippage_cost > 0

    rejected = ex.execute("buy", 65000, 2)
    assert rejected is None

    capped = ex.execute("buy", 65000, 100)
    assert capped.executed_quote == 25

    print("REALISTIC EXECUTION TESTS PASSED")
    print("buy:", buy)
    print("sell:", sell)
    print("min-notional rejection: PASS")
    print("order cap: PASS")

if __name__ == "__main__":
    main()
