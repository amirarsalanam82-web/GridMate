"""Download public Binance Spot OHLCV data.

Uses the official public REST API. No API key is required for market-data klines.
Run when internet access is available.
"""
import csv, json, time, urllib.parse, urllib.request
from datetime import datetime, timezone

BASE_URL = 'https://api.binance.com/api/v3/klines'


def _ms(value):
    if value is None: return None
    if isinstance(value, (int, float)): return int(value)
    dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def download_klines(symbol='BTCUSDT', interval='1h', limit=1000, start=None, end=None, out='btc_usdt_1h.csv'):
    start_ms, end_ms = _ms(start), _ms(end)
    rows = []
    while len(rows) < limit:
        params = {'symbol': symbol.upper(), 'interval': interval, 'limit': min(1000, limit-len(rows))}
        if start_ms is not None: params['startTime'] = start_ms
        if end_ms is not None: params['endTime'] = end_ms
        url = BASE_URL + '?' + urllib.parse.urlencode(params)
        with urllib.request.urlopen(url, timeout=20) as r:
            batch = json.loads(r.read().decode())
        if not batch: break
        rows.extend(batch)
        if len(batch) < params['limit']: break
        start_ms = int(batch[-1][0]) + 1
        time.sleep(0.1)
    with open(out, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f); w.writerow(['timestamp','open','high','low','close','volume'])
        for k in rows[:limit]:
            ts = datetime.fromtimestamp(k[0]/1000, tz=timezone.utc).isoformat()
            w.writerow([ts, k[1], k[2], k[3], k[4], k[5]])
    return out, len(rows[:limit])

if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(); p.add_argument('--symbol', default='BTCUSDT'); p.add_argument('--interval', default='1h'); p.add_argument('--limit', type=int, default=1000); p.add_argument('--out', default='btc_usdt_1h.csv'); p.add_argument('--start'); p.add_argument('--end')
    a = p.parse_args(); print(download_klines(a.symbol, a.interval, a.limit, a.start, a.end, a.out))
