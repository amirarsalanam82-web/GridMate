"""Conservative restart/reconnect recovery coordinator."""
from typing import Any, Dict

TERMINAL = {"FILLED", "CANCELED", "REJECTED", "EXPIRED", "ERROR"}

class RecoveryCoordinator:
    def __init__(self, manager, exchange):
        self.manager = manager
        self.exchange = exchange

    def recover(self, symbol=None) -> Dict[str, Any]:
        """Reconcile open orders, then explicitly resolve locally-open orders.

        Missing orders are never assumed filled. If a detail lookup fails, the
        order remains UNKNOWN_RECOVERY and the runner should stay stopped.
        """
        result = {"open_synced": 0, "resolved": 0, "uncertain": [], "safe_to_run": False}
        try:
            result["open_synced"] = self.exchange.reconcile_open_orders(self.manager, symbol)
        except Exception as exc:
            result["uncertain"].append({"reason": "open_orders_failed", "error": str(exc)})
            return result

        for order in list(self.manager.open_orders()):
            try:
                detail = self.exchange.order(order.client_id)
                normalized = self.exchange.normalize_order(detail)
                status = normalized.get("status", "UNKNOWN").upper()
                if status in TERMINAL:
                    self.manager.finalize(order.client_id, status)
                    result["resolved"] += 1
                elif status in {"NEW", "PARTIALLY_FILLED", "CANCEL_REQUESTED"}:
                    self.manager.reconcile(order.client_id, status)
                else:
                    result["uncertain"].append({"client_id": order.client_id, "status": status})
            except Exception as exc:
                result["uncertain"].append({"client_id": order.client_id, "reason": "detail_lookup_failed", "error": str(exc)})

        result["safe_to_run"] = not result["uncertain"] and not self.manager.kill_switch
        return result
