# GridMate v0.4.6 — Continuous Session Safety

Added a persistent session coordinator for long-running operation.

- Recovery is mandatory before the runner can start.
- Market heartbeat timeout stops the runner when data becomes stale.
- Disconnect explicitly stops new trading activity.
- Session timestamp state is persisted without secrets.
- Unknown/recovery failure remains fail-closed.

This is still a safety/paper-run layer; it does not prove profitability and does not authorize real-money trading by itself.
