# GridMate v0.4.5 — Recovery & Persistence

- Added SQLite state persistence for order lifecycle and kill-switch state.
- Added conservative recovery coordinator.
- On restart/reconnect, open orders are reconciled first.
- Orders missing from the open-order list are explicitly looked up before being finalized.
- If exchange lookup fails or returns an unknown status, the bot remains unsafe to run.
- No API keys or secrets are stored in SQLite.
- Withdrawals remain unsupported.

Recovery policy: **uncertain state => stop, do not submit new orders.**
