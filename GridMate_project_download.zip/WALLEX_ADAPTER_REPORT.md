# GridMate v0.4.2 — Wallex adapter

- Official Wallex REST API adapter added.
- Uses `X-API-Key` authentication.
- Supports balances, markets, depth, fees, open orders, order lookup, LIMIT buy/sell, cancel, and account trades.
- Withdrawal is intentionally absent from the adapter.
- Client order IDs are passed through for reconciliation/idempotency.
- No API key is stored in source code.
