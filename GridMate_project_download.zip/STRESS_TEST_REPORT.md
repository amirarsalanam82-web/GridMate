# GridMate v0.3.4 — Stress Test Report

سناریوهای تست‌شده:
- flat
- range
- uptrend
- downtrend
- sharp_drop
- volatile

همه تست‌های پایه‌ی سلامت موتور پاس شدند و در سناریوی sharp_drop، Stop Loss فعال شد.

این نتایج به هیچ‌وجه تضمین سودآوری نیستند. هنوز تست داده تاریخی واقعی، slippage، partial fills، محدودیت‌های precision/min-notional و محیط Demo لازم است.

Results: {'flat': {'starting_quote': 1000, 'ending_equity': 1000.0, 'return_pct': 0.0, 'max_drawdown_pct': 0.0, 'trades': 0, 'fees': 0.0, 'realized_pnl': 0.0, 'base_position': 0.0, 'cash': 1000, 'stop_triggered': False, 'bars': 100}, 'range': {'starting_quote': 1000, 'ending_equity': 1273.78991564, 'return_pct': 27.379, 'max_drawdown_pct': 0.5358, 'trades': 315, 'fees': 7.875, 'realized_pnl': 11.69501336, 'base_position': 0.00082064, 'cash': 1217.125, 'stop_triggered': False, 'bars': 200}, 'uptrend': {'starting_quote': 1000, 'ending_equity': 1000.0, 'return_pct': 0.0, 'max_drawdown_pct': 0.0, 'trades': 0, 'fees': 0.0, 'realized_pnl': 0.0, 'base_position': 0.0, 'cash': 1000, 'stop_triggered': False, 'bars': 220}, 'downtrend': {'starting_quote': 1000, 'ending_equity': 961.41422735, 'return_pct': -3.8586, 'max_drawdown_pct': 3.8586, 'trades': 18, 'fees': 0.45, 'realized_pnl': 0.0, 'base_position': 0.00696364, 'cash': 549.55, 'stop_triggered': False, 'bars': 220}, 'sharp_drop': {'starting_quote': 1000, 'ending_equity': 975.67561077, 'return_pct': -2.4324, 'max_drawdown_pct': 2.4324, 'trades': 16, 'fees': 0.4, 'realized_pnl': 0.0, 'base_position': 0.00637416, 'cash': 599.6, 'stop_triggered': True, 'bars': 8}, 'volatile': {'starting_quote': 1000, 'ending_equity': 2203.87427126, 'return_pct': 120.3874, 'max_drawdown_pct': 7.1791, 'trades': 1010, 'fees': 25.22910337, 'realized_pnl': 578.63134084, 'base_position': 0.0, 'cash': 2203.87427126, 'stop_triggered': False, 'bars': 240}}
