# Android API Contract — v0.3.4

The Android app should only need these backend operations:

- `GET /health` — connection check
- `POST /backtest` — run a backtest
- `GET /status` — future paper/demo status
- `POST /configure` — future paper/demo configuration
- `POST /start` / `POST /stop` / `POST /reset` — future controls

The Android UI must not contain exchange secrets. Real credentials, if ever used,
belong on a secured backend/secret store and must never include withdrawal permission.
