# Real market data plan

The project now contains a downloader for public Binance Spot OHLCV data (`backend/binance_klines.py`).
It uses the official REST kline endpoint and needs no API key for public market data.

Important: the current execution environment cannot reach external DNS/network, so the downloader was not run here. No fabricated market results are included.

Next validation sequence:
1. Download a fixed BTCUSDT 1h dataset.
2. Freeze the dataset and record source/time range.
3. Run GridMate v0.3.8 with conservative fee/slippage settings.
4. Run at least flat/range/uptrend/downtrend/shock segments from the same dataset.
5. Compare with a buy-and-hold baseline.
6. Only after that, move to Binance Demo/Testnet integration.
