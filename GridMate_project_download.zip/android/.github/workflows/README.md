# Cloud APK build

The `android-apk.yml` workflow builds `app-debug.apk` on GitHub Actions.
The app remains Paper/Dry-Run by default; this workflow does not configure exchange credentials.
