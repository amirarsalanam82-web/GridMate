plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gridmate.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gridmate.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 52
        versionName = "0.5.2"
    }
}

kotlin {
    jvmToolchain(17)
}
