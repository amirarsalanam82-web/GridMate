package com.gridmate.app.exchange

/** Network boundary only. Live order submission stays behind an explicit safety gate. */
interface WallexClient {
    suspend fun accountSummary(): String
    suspend fun openOrders(symbol: String): String
    suspend fun orderStatus(orderId: String): String
    suspend fun cancelOrder(orderId: String): String
}
