package com.gridmate.app

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.gridmate.app.core.EngineState
import com.gridmate.app.core.GridConfig
import com.gridmate.app.core.GridEngine
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var engine: GridEngine? = null
    private var lastPrice = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        val price = findViewById<EditText>(R.id.price)

        val symbol = findViewById<EditText>(R.id.symbol)
        val lower = findViewById<EditText>(R.id.lower)
        val upper = findViewById<EditText>(R.id.upper)
        val grids = findViewById<EditText>(R.id.grids)
        val order = findViewById<EditText>(R.id.orderSize)
        val stop = findViewById<EditText>(R.id.stopLoss)

        findViewById<Button>(R.id.connect).setOnClickListener {
            status.text = "حالت Paper/Dry-Run آماده است؛ بدون کامپیوتر هم قابل اجراست."
        }
        findViewById<Button>(R.id.start).setOnClickListener {
            runCatching {
                val lo = lower.text.toString().toDouble()
                val hi = upper.text.toString().toDouble()
                val n = grids.text.toString().toInt()
                val q = order.text.toString().toDouble()
                val sl = (stop.text.toString().toDoubleOrNull() ?: 0.0) / 100.0
                require(lo > 0 && hi > lo && n > 0 && q > 0) { "تنظیمات گرید نامعتبر است" }
                engine = GridEngine(GridConfig(symbol.text.toString().ifBlank { "BTCUSDT" }, lo, hi, n, q, stopLossPct = sl), q * n * 2)
                engine!!.start()
                status.text = "ربات Paper/Dry-Run شروع شد"
            }.onFailure { status.text = "خطا: ${it.message}" }
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            engine?.stop()
            status.text = "ربات متوقف شد"
        }
        findViewById<Button>(R.id.kill).setOnClickListener {
            engine?.kill()
            status.text = "KILL SWITCH فعال شد"
        }
        findViewById<Button>(R.id.tick).setOnClickListener {
            runCatching {
                lastPrice = price.text.toString().toDouble()
                val snap = engine?.onPrice(lastPrice) ?: error("ابتدا ربات را شروع کنید")
                status.text = String.format(Locale.US, "وضعیت: %s\nEquity: %.2f\nCash: %.2f\nBase: %.8f\nRealized P&L: %.2f\nUnrealized P&L: %.2f", snap.state, snap.equity, snap.cash, snap.base, snap.realizedPnl, snap.unrealizedPnl)
            }.onFailure { status.text = "خطا: ${it.message}" }
        }
        findViewById<Button>(R.id.refresh).setOnClickListener {
            status.text = snapshotText()
        }
    }

    private fun snapshotText(): String {
        val e = engine ?: return "وضعیت: هنوز شروع نشده"
        return String.format(Locale.US, "وضعیت: %s\nقیمت: %.4f", e.onPrice(lastPrice).state, lastPrice)
    }
}
