package com.gridmate.app.core

import kotlin.math.abs

enum class EngineState { STOPPED, RUNNING, KILLED, BLOCKED }

data class EngineSnapshot(
    val state: EngineState,
    val price: Double,
    val cash: Double,
    val base: Double,
    val equity: Double,
    val realizedPnl: Double,
    val unrealizedPnl: Double,
    val reason: String? = null
)

class GridEngine(private val config: GridConfig, startingCash: Double) {
    private val levels = (0..config.grids).map { i ->
        config.lower + (config.upper - config.lower) * i / config.grids
    }
    private var state = EngineState.STOPPED
    private var cash = startingCash
    private var base = 0.0
    private var realized = 0.0
    private var lastPrice = config.lower
    private var lastEquity = startingCash
    private var reason: String? = null

    fun start() { if (state != EngineState.KILLED) { state = EngineState.RUNNING; reason = null } }
    fun stop() { if (state != EngineState.KILLED) state = EngineState.STOPPED }
    fun kill() { state = EngineState.KILLED; reason = "Kill switch" }

    fun onPrice(price: Double): EngineSnapshot {
        if (price <= 0.0) return snapshot(price)
        if (state == EngineState.RUNNING) {
            val stopPrice = config.lower * (1.0 - config.stopLossPct)
            if (stopPrice > 0 && price <= stopPrice) {
                if (base > 0) {
                    cash += base * price * (1.0 - config.feeRate)
                    base = 0.0
                }
                state = EngineState.BLOCKED
                reason = "Stop loss"
            } else {
                val crossedDown = lastPrice > price
                val crossedUp = lastPrice < price
                if (crossedDown) buyAtNearestLevel(price)
                if (crossedUp) sellAtNearestLevel(price)
            }
        }
        lastPrice = price
        return snapshot(price)
    }

    private fun buyAtNearestLevel(price: Double) {
        val level = levels.filter { it < lastPrice && it >= price }.maxOrNull() ?: return
        val quote = minOf(config.quotePerOrder, config.maxQuoteExposure, cash)
        if (quote <= 0.0 || quote * (1.0 - config.feeRate) <= 0.0) return
        val spent = quote
        val acquired = (spent * (1.0 - config.feeRate)) / level
        cash -= spent
        base += acquired
    }

    private fun sellAtNearestLevel(price: Double) {
        val level = levels.filter { it > lastPrice && it <= price }.minOrNull() ?: return
        if (base <= 0.0) return
        val quote = minOf(config.quotePerOrder, base * level)
        val soldBase = quote / level
        val proceeds = quote * (1.0 - config.feeRate)
        base -= soldBase
        cash += proceeds
        realized += proceeds - quote
    }

    private fun snapshot(price: Double): EngineSnapshot {
        val equity = cash + base * price
        val unrealized = equity - lastEquity - realized
        lastEquity = equity
        return EngineSnapshot(state, price, cash, base, equity, realized, unrealized, reason)
    }
}
