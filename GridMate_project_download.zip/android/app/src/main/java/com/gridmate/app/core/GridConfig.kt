package com.gridmate.app.core

data class GridConfig(
    val symbol: String = "BTCUSDT",
    val lower: Double,
    val upper: Double,
    val grids: Int,
    val quotePerOrder: Double,
    val feeRate: Double = 0.001,
    val stopLossPct: Double = 0.05,
    val maxQuoteExposure: Double = 1000.0
)
