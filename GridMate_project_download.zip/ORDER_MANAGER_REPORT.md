# GridMate v0.4.1 — Order Manager / Kill Switch

This version adds a local, exchange-agnostic order lifecycle layer for Demo integration.

Safety controls:
- idempotent client order IDs (prevents duplicate submission on retry)
- maximum open orders
- maximum quote value per order
- kill switch that blocks new submissions and marks open orders for cancellation
- explicit reconciliation of local status with exchange status
- no withdrawal/transfer functionality

The manager is intentionally separated from the Binance adapter so the exchange client cannot bypass local safety limits.
