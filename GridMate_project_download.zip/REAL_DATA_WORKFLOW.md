# Real-data workflow

1. Download public OHLCV klines from an official exchange market-data endpoint.
2. Preserve the raw CSV unchanged.
3. Validate timestamps are increasing and OHLC relationships are valid.
4. Run GridMate and Buy & Hold on the exact same dataset.
5. Split data chronologically into development and out-of-sample periods.
6. Do not tune parameters on the out-of-sample period.
7. Report fees, slippage, rejected orders, drawdown and stop-loss events.
8. Only after stable results should Demo trading be considered.

No API key is required for public market-data download. Trading credentials are never needed for this stage.
