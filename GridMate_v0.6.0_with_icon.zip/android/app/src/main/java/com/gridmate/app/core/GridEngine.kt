package com.gridmate.app.core

enum class EngineState { STOPPED, RUNNING, KILLED, BLOCKED }

data class EngineSnapshot(
    val state: EngineState,
    val price: Double,
    val cash: Double,
    val base: Double,
    val equity: Double,
    val realizedPnl: Double,
    val unrealizedPnl: Double,
    val totalPnl: Double,
    val drawdownPct: Double,
    val trades: Int,
    val reason: String? = null
)

class GridEngine(private val config: GridConfig, private val startingCash: Double) {
    private val levels = (0..config.grids).map { i ->
        config.lower + (config.upper - config.lower) * i / config.grids
    }
    private var state = EngineState.STOPPED
    private var cash = startingCash
    private var base = 0.0
    private var costBasis = 0.0
    private var realized = 0.0
    private var lastPrice = config.lower
    private var peakEquity = startingCash
    private var trades = 0
    private var reason: String? = null

    fun start() {
        if (state != EngineState.KILLED) {
            state = EngineState.RUNNING
            reason = null
        }
    }

    fun stop() { if (state != EngineState.KILLED) state = EngineState.STOPPED }
    fun kill() { state = EngineState.KILLED; reason = "Kill switch" }

    fun onPrice(price: Double): EngineSnapshot {
        if (price <= 0.0) return snapshot(lastPrice)
        if (state == EngineState.RUNNING) {
            val stopPrice = config.lower * (1.0 - config.stopLossPct)
            if (config.stopLossPct > 0 && price <= stopPrice) {
                if (base > 0) sellAllAt(price)
                state = EngineState.BLOCKED
                reason = "Stop loss"
            } else {
                processCrossedLevels(lastPrice, price)
            }
        }
        lastPrice = price
        return snapshot(price)
    }

    private fun processCrossedLevels(from: Double, to: Double) {
        if (to < from) {
            levels.filter { it < from && it >= to }.sortedDescending().forEach { buyAt(it) }
        } else if (to > from) {
            levels.filter { it > from && it <= to }.sorted().forEach { sellAt(it) }
        }
    }

    private fun buyAt(level: Double) {
        val quote = minOf(config.quotePerOrder, config.maxQuoteExposure, cash)
        if (quote <= 0.0) return
        val acquired = (quote * (1.0 - config.feeRate)) / level
        cash -= quote
        base += acquired
        costBasis += quote
        trades++
    }

    private fun sellAt(level: Double) {
        if (base <= 0.0) return
        val grossQuote = minOf(config.quotePerOrder, base * level)
        val soldBase = grossQuote / level
        val fee = grossQuote * config.feeRate
        val proceeds = grossQuote - fee
        val costSold = if (base > 0) costBasis * (soldBase / base) else 0.0
        base -= soldBase
        cash += proceeds
        costBasis -= costSold
        realized += proceeds - costSold
        trades++
    }

    private fun sellAllAt(price: Double) {
        if (base <= 0.0) return
        val grossQuote = base * price
        val proceeds = grossQuote * (1.0 - config.feeRate)
        realized += proceeds - costBasis
        cash += proceeds
        base = 0.0
        costBasis = 0.0
        trades++
    }

    private fun snapshot(price: Double): EngineSnapshot {
        val equity = cash + base * price
        if (equity > peakEquity) peakEquity = equity
        val drawdown = if (peakEquity > 0) ((peakEquity - equity) / peakEquity) * 100.0 else 0.0
        val totalPnl = equity - startingCash
        val unrealized = totalPnl - realized
        return EngineSnapshot(
            state = state,
            price = price,
            cash = cash,
            base = base,
            equity = equity,
            realizedPnl = realized,
            unrealizedPnl = unrealized,
            totalPnl = totalPnl,
            drawdownPct = drawdown,
            trades = trades,
            reason = reason
        )
    }
}
