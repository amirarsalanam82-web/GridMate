package com.gridmate.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.gridmate.app.core.EngineSnapshot
import com.gridmate.app.core.GridConfig
import com.gridmate.app.core.GridEngine
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var metrics: TextView
    private lateinit var price: EditText
    private var engine: GridEngine? = null
    private var lastPrice = 0.0
    private val handler = Handler(Looper.getMainLooper())
    private var simDirection = 1
    private var simulationRunning = false

    private val simulator = object : Runnable {
        override fun run() {
            if (!simulationRunning) return
            val e = engine ?: return
            if (lastPrice <= 0.0) return
            val lower = findViewById<EditText>(R.id.lower).text.toString().toDoubleOrNull() ?: return
            val upper = findViewById<EditText>(R.id.upper).text.toString().toDoubleOrNull() ?: return
            val step = max((upper - lower) / 5.0, 1.0) / 2.0
            var next = lastPrice + simDirection * step
            if (next >= upper) { next = upper; simDirection = -1 }
            if (next <= lower) { next = lower; simDirection = 1 }
            val snap = e.onPrice(next)
            lastPrice = next
            render(snap)
            handler.postDelayed(this, 1200)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        metrics = findViewById(R.id.metrics)
        price = findViewById(R.id.price)

        val symbol = findViewById<EditText>(R.id.symbol)
        val lower = findViewById<EditText>(R.id.lower)
        val upper = findViewById<EditText>(R.id.upper)
        val grids = findViewById<EditText>(R.id.grids)
        val order = findViewById<EditText>(R.id.orderSize)
        val stop = findViewById<EditText>(R.id.stopLoss)

        findViewById<Button>(R.id.connect).setOnClickListener {
            status.text = "وضعیت: BLOCKED — Paper آماده است؛ حساب واقعی عمداً وصل نشده"
        }

        findViewById<Button>(R.id.start).setOnClickListener {
            runCatching {
                val lo = lower.text.toString().toDouble()
                val hi = upper.text.toString().toDouble()
                val n = grids.text.toString().toInt()
                val q = order.text.toString().toDouble()
                val sl = (stop.text.toString().toDoubleOrNull() ?: 0.0) / 100.0
                val initial = price.text.toString().toDouble()
                require(lo > 0 && hi > lo && n > 0 && q > 0 && initial > 0) { "قیمت و تنظیمات گرید را کامل کن" }
                require(initial in lo..hi) { "قیمت شروع باید بین کف و سقف گرید باشد" }
                engine = GridEngine(GridConfig(symbol.text.toString().ifBlank { "BTCUSDT" }, lo, hi, n, q, stopLossPct = sl), q * n * 2)
                engine!!.start()
                lastPrice = initial
                simDirection = 1
                val snap = engine!!.onPrice(initial)
                simulationRunning = true
                handler.removeCallbacks(simulator)
                handler.postDelayed(simulator, 900)
                render(snap)
            }.onFailure { status.text = "خطا: ${it.message}" }
        }

        findViewById<Button>(R.id.stop).setOnClickListener {
            simulationRunning = false
            handler.removeCallbacks(simulator)
            engine?.stop()
            status.text = "وضعیت: STOPPED"
        }

        findViewById<Button>(R.id.kill).setOnClickListener {
            simulationRunning = false
            handler.removeCallbacks(simulator)
            engine?.kill()
            status.text = "وضعیت: KILLED — توقف اضطراری فعال شد"
        }

        findViewById<Button>(R.id.tick).setOnClickListener {
            runCatching {
                val p = price.text.toString().toDouble()
                require(p > 0) { "قیمت را وارد کن" }
                lastPrice = p
                val snap = engine?.onPrice(p) ?: error("ابتدا ربات را شروع کنید")
                render(snap)
            }.onFailure { status.text = "خطا: ${it.message}" }
        }

        findViewById<Button>(R.id.refresh).setOnClickListener {
            val e = engine ?: run { status.text = "وضعیت: هنوز شروع نشده"; return@setOnClickListener }
            render(e.onPrice(lastPrice))
        }
    }

    private fun render(snap: EngineSnapshot) {
        status.text = String.format(Locale.US, "وضعیت: %s\nقیمت فعلی: %.2f", snap.state, snap.price)
        metrics.text = String.format(
            Locale.US,
            "P&L کل: %.2f\nP&L تحقق‌یافته: %.2f\nP&L شناور: %.2f\nEquity: %.2f\nCash: %.2f\nBase: %.8f\nDrawdown: %.2f%%\nتعداد معاملات: %d",
            snap.totalPnl, snap.realizedPnl, snap.unrealizedPnl, snap.equity, snap.cash, snap.base, snap.drawdownPct, snap.trades
        )
    }

    override fun onDestroy() {
        simulationRunning = false
        handler.removeCallbacks(simulator)
        super.onDestroy()
    }
}
